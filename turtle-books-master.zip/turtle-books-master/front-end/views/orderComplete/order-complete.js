// const orderList = document.querySelector("#orderList");

// async function loadOrderList() {
//   try {
//     const response = await fetch("/api/orderList", {
//       method: "GET",
//       headers: {
//         "content-Type": "application/json",
//       },
//     });
//     if (response.ok) {
//       const data = await response.json();
//       console.log(data);
//     }
//   } catch (error) {
//     console.log(error.message);
//   }
// }
